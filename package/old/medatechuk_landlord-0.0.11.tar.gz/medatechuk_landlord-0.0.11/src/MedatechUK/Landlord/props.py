from pyqtgraph.parametertree import ParameterTree

class myProps(ParameterTree):
    def __init__(self , parent=None):
        super().__init__(parent)        